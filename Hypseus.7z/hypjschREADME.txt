
Hypseus Joystick Configuration Helper (hypjsch) v1.1
====================================================

Copy the relevant .exe to your Hypseus directory.

Connect your joysticks and run "hypjsch_x86.exe" or "hypjsch_x64.exe".

The utility will provide example config (hypinput.ini) for the detected joystick actions.


See further details: https://github.com/DirtBagXon/hypjsch

