Hypseus Singe example .bat files
================================

https://github.com/DirtBagXon/hypseus-singe

These example .bat files should be run within the folder containing hypseus.exe and the relevant game sub directories: vldp_dl, vldp and singe.

Check the log file logs/hypseus.log in case of issues.

Note: This zipfile includes the flightkey.ini configuration file, which will be used, if present in directory, and reverse up/down keys on the flight based games.

GameController configuration can be enabled with the '-gamepad' argument. See configuration options in the example README_GAMECONTROLLER.txt file contained in this zip.


SINGE
=====

Always check https://github.com/DirtBagXon/hypseus_singe_data for updates to Singe based games
