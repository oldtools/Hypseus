Subsystem Windows GUI linking
=============================

This is the 64bit Windows Hypseus binary (v2.10.1) linked with -Wl,-subsystem,windows.

When launched from EmulationStation is can remove the opening of the Command Prompt Window.

Use the hypseus.exe binary in this zip to replace the main release binary.




