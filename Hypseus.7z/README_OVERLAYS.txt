Hypseus can now support full resolution overlays.

This will require the game to have support, i.e. full Singe 2 games.

Enable this within your .bat file via the '-set_overlay' argument.

-set_overlay               [ Enforce overlay size (full, half, oversize)   ]
                           [ (full): Set to full video resolution [Singe2] ]
                           [ (half): Set to half video resolution [Singe2] ]
                           [ (oversize): Use with HD gungame video sources ]

